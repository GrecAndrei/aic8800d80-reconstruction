#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <inttypes.h>

#define LOBYTE(x) ((uint8_t)((x) & 0xFF))
#define HIBYTE(x) ((uint8_t)(((x) >> 8) & 0xFF))
#define LOWORD(x) ((uint16_t)((x) & 0xFFFF))
#define HIWORD(x) ((uint16_t)(((x) >> 16) & 0xFFFF))
#define LODWORD(x) ((uint32_t)(x))
#define HIDWORD(x) ((uint32_t)(((uint64_t)(x) >> 32)))

extern uint32_t off_108400;
extern uint32_t off_108434;
extern uint32_t off_108404;
extern uint32_t off_10843C;
extern uint32_t off_108408;
extern uint32_t off_108440;
extern uint32_t off_108444;
extern uint32_t off_108438;
extern uint32_t off_10840C;
extern uint32_t off_108410;
extern uint32_t off_108414;
extern uint32_t off_108418;
extern uint32_t off_10841C;
extern uint32_t off_108420;
extern uint32_t off_108424;
extern uint32_t off_108428;
extern uint32_t off_10842C;
extern uint32_t off_108430;
extern uint32_t dword_10876C;
extern uint32_t off_108770;
extern uint32_t off_108774;
extern uint32_t off_1087B4;
extern uint32_t off_1087B8;
extern uint32_t off_1087BC;
extern uint32_t dword_108778;
extern uint32_t dword_10877C;
extern uint32_t dword_108780;
extern uint32_t dword_108784;
extern uint32_t dword_1087C0;
extern uint32_t dword_10878C;
extern uint32_t off_108790;
extern uint32_t dword_108788;
extern uint32_t dword_108794;
extern uint32_t dword_109178;
extern uint32_t dword_108798;
extern uint32_t dword_10879C;
extern uint32_t dword_1087A0;
extern uint32_t dword_1087A4;
extern uint32_t dword_1087A8;
extern uint32_t dword_1087AC;
extern uint32_t dword_109180;
extern uint32_t dword_1087B0;
extern uint32_t dword_108AAC;
extern uint32_t dword_108AB0;
extern uint32_t dword_108AB4;
extern uint32_t dword_108AB8;
extern uint32_t dword_108ABC;
extern uint32_t off_108AC0;
extern uint32_t off_108AC4;
extern uint32_t off_108AC8;
extern uint32_t dword_10917C;
extern uint32_t dword_108E3C;
extern uint32_t dword_108E38;
extern uint32_t dword_108E40;
extern uint32_t dword_108E44;
extern uint32_t dword_108E48;
extern uint32_t off_108E50;
extern uint32_t off_108E54;
extern uint32_t off_108E4C;
extern uint32_t dword_109184;
extern uint32_t dword_108E58;
extern uint32_t dword_108E5C;
extern uint32_t dword_108E60;
extern uint32_t off_108E64;
extern uint32_t off_108E68;
extern uint32_t off_108E90;
extern uint32_t off_108E94;
extern uint32_t off_108E98;
extern uint32_t off_108E9C;
extern uint32_t off_108E6C;
extern uint32_t off_108E70;
extern uint32_t off_108E74;
extern uint32_t off_108E78;
extern uint32_t off_108E7C;
extern uint32_t dword_108E80;
extern uint32_t off_108E84;
extern uint32_t off_108E88;
extern uint32_t off_108E8C;
extern uint32_t off_10916C;
extern uint32_t off_109170;
extern uint32_t off_109174;
extern uint32_t dword_108AD0;
extern uint32_t dword_108ACC;
extern uint32_t off_108AD4;
extern uint32_t dword_108AD8;
extern uint32_t dword_108ADC;
extern uint32_t dword_108AE0;
extern uint32_t off_108AE4;
extern uint32_t dword_108AE8;
extern uint32_t dword_108AEC;
extern uint32_t off_108AF0;
extern uint32_t dword_108AF4;
extern uint32_t off_108AF8;
extern uint32_t dword_108AFC;

// sub_108140 @ 0x108140, size 4140 bytes
uint32_t * sub_108140(int a1, unsigned int *a2, int a3, unsigned int a4, unsigned int a5, int a6, int16_t a7)
{
  int *v7; // r4
  unsigned int *v8; // lr
  unsigned int *v9; // r5
  uint32_t *v10; // r12
  int *v11; // r6
  unsigned int *v12; // r11
  int *v13; // r8
  int *v14; // r7
  unsigned int v15; // r5
  void *v17; // r3
  void *v18; // r3
  void *v19; // r3
  uint32_t *v20; // r3
  int v21; // r6
  uint32_t *v22; // r0
  uint32_t *v23; // r2
  unsigned int *v24; // r1
  uint32_t *v25; // r2
  int v26; // r0
  uint32_t *v27; // r3
  unsigned int *v28; // r9
  int *v29; // r11
  int *v30; // r10
  int v31; // r1
  int v32; // r2
  int v33; // s16
  int v34; // r4
  int v35; // r7
  int v36; // r8
  int v37; // r1
  int v38; // r4
  int i; // r6
  int v40; // r5
  int v41; // r3
  int v42; // r2
  int v43; // r6
  int v44; // r1
  int v45; // r6
  int v46; // r5
  int v47; // r3
  signed int v48; // r6
  signed int v49; // r5
  int v50; // r1
  int v51; // r6
  int *v52; // r0
  unsigned int *v53; // r1
  unsigned int *v54; // r3
  int v55; // r2
  int v56; // r5
  int v57; // r4
  int v58; // r7
  int v59; // r6
  int v60; // r10
  void *v61; // r2
  int v62; // r0
  int v63; // r9
  int v64; // r5
  int v65; // r2
  void *v66; // r2
  int v67; // r0
  unsigned int *v68; // r1
  int *v69; // r2
  int v70; // r0
  int *v71; // r4
  uint32_t *result; // r0
  int v73; // r1
  int v74; // r4
  int v75; // r5
  signed int v76; // r6
  signed int v77; // r4
  unsigned int *v78; // r1
  unsigned int *v79; // r3
  int v80; // cc
  int v81; // r1
  unsigned int *v82; // r1
  unsigned int *v83; // r0
  unsigned int *v84; // r11
  unsigned int *v85; // r12
  uint32_t *v86; // r10
  uint32_t *v87; // r9
  unsigned int *v88; // r3
  unsigned int *v89; // r2
  unsigned int *v90; // r4
  unsigned int *v91; // r0
  unsigned int *v92; // r1
  int v93; // r6
  uint32_t *v94; // r7
  unsigned int *v95; // r2
  uint32_t *v96; // r5
  uint32_t *v97; // r5
  unsigned int *v98; // r1
  int v99; // [sp+8h] [bp-1ECh]
  int v100; // [sp+8h] [bp-1ECh]
  int v101; // [sp+Ch] [bp-1E8h]
  int v102; // [sp+10h] [bp-1E4h]
  int v103; // [sp+14h] [bp-1E0h]
  int v104; // [sp+18h] [bp-1DCh]
  int v105; // [sp+1Ch] [bp-1D8h]
  char *v106; // [sp+20h] [bp-1D4h]
  int v107; // [sp+24h] [bp-1D0h]
  int v108; // [sp+28h] [bp-1CCh]
  int v109; // [sp+2Ch] [bp-1C8h]
  int v110; // [sp+30h] [bp-1C4h]
  int v111; // [sp+34h] [bp-1C0h]
  int v112; // [sp+38h] [bp-1BCh]
  int v113; // [sp+3Ch] [bp-1B8h]
  int v114; // [sp+40h] [bp-1B4h]
  int v115; // [sp+44h] [bp-1B0h]
  unsigned int v116; // [sp+48h] [bp-1ACh]
  int v117; // [sp+4Ch] [bp-1A8h]
  unsigned int v118; // [sp+50h] [bp-1A4h]
  int v119; // [sp+54h] [bp-1A0h]
  int v120; // [sp+58h] [bp-19Ch]
  int v121; // [sp+5Ch] [bp-198h]
  int v122; // [sp+60h] [bp-194h]
  int v123; // [sp+64h] [bp-190h]
  int v124; // [sp+68h] [bp-18Ch]
  int v125; // [sp+6Ch] [bp-188h]
  int v126; // [sp+70h] [bp-184h]
  int v127; // [sp+74h] [bp-180h]
  int v128; // [sp+78h] [bp-17Ch]
  int v129; // [sp+7Ch] [bp-178h]
  int v130; // [sp+80h] [bp-174h]
  int v131; // [sp+84h] [bp-170h]
  int v132; // [sp+88h] [bp-16Ch]
  int v133; // [sp+8Ch] [bp-168h]
  int v134; // [sp+90h] [bp-164h]
  int v135; // [sp+94h] [bp-160h]
  unsigned int v136; // [sp+98h] [bp-15Ch]
  int v137; // [sp+9Ch] [bp-158h]
  unsigned int v138; // [sp+A0h] [bp-154h]
  int v139; // [sp+A4h] [bp-150h]
  unsigned int v140; // [sp+A8h] [bp-14Ch]
  int v141; // [sp+ACh] [bp-148h]
  unsigned int v142; // [sp+B0h] [bp-144h]
  int v143; // [sp+B4h] [bp-140h]
  unsigned int v144; // [sp+B8h] [bp-13Ch]
  unsigned int v145; // [sp+BCh] [bp-138h]
  int v146; // [sp+C0h] [bp-134h]
  int v147; // [sp+C4h] [bp-130h]
  int v148; // [sp+C8h] [bp-12Ch]
  int v149; // [sp+CCh] [bp-128h]
  int v150; // [sp+D0h] [bp-124h]
  int v151; // [sp+D4h] [bp-120h]
  int v152; // [sp+D8h] [bp-11Ch]
  int v153; // [sp+DCh] [bp-118h]
  int v154; // [sp+E0h] [bp-114h]
  int v155; // [sp+E4h] [bp-110h]
  int v156; // [sp+E8h] [bp-10Ch]
  int v157; // [sp+ECh] [bp-108h]
  int v158; // [sp+F0h] [bp-104h]
  int v160; // [sp+F8h] [bp-FCh]
  int v161; // [sp+FCh] [bp-F8h]
  unsigned int *v163; // [sp+104h] [bp-F0h]
  uint32_t v164[3]; // [sp+108h] [bp-ECh]
  unsigned int v165[4]; // [sp+114h] [bp-E0h] BYREF
  int v166; // [sp+124h] [bp-D0h] BYREF
  int v167; // [sp+128h] [bp-CCh]
  int v168; // [sp+12Ch] [bp-C8h]
  uint64_t v169; // [sp+130h] [bp-C4h]
  unsigned int v170; // [sp+150h] [bp-A4h]
  uint32_t v171[10]; // [sp+154h] [bp-A0h] BYREF
  char v172; // [sp+17Ch] [bp-78h] BYREF
  int v173; // [sp+18Ch] [bp-68h]
  int v174; // [sp+198h] [bp-5Ch] BYREF
  int v175; // [sp+19Ch] [bp-58h]
  int v176; // [sp+1A0h] [bp-54h]
  int v177; // [sp+1A4h] [bp-50h]

  v7 = (int *)off_108400;
  v8 = (unsigned int *)off_108434;
  v9 = (unsigned int *)off_108404;
  v10 = off_10843C;
  v11 = (int *)off_108408;
  v12 = (unsigned int *)off_108440;
  v13 = (int *)off_108444;
  v158 = *(uint32_t *)off_108438;
  v157 = *(uint32_t *)off_108400;
  v156 = *(uint32_t *)off_108400;
  v155 = *(uint32_t *)off_108434;
  v154 = *(uint32_t *)off_108404;
  v153 = *(uint32_t *)off_108404;
  v152 = *(uint32_t *)off_108404;
  v151 = *(uint32_t *)off_108404;
  v150 = *(uint32_t *)off_10843C;
  v149 = *(uint32_t *)off_10843C;
  v148 = *(uint32_t *)off_108408;
  v147 = *(uint32_t *)off_108400;
  v146 = *(uint32_t *)off_108400;
  *(uint32_t *)off_108438 = *(uint32_t *)off_108438 & 0xF8FFFFFF | 0x1000000;
  v14 = (int *)off_10840C;
  *v7 |= 0x100000u;
  *v7 |= 0x200000u;
  *v8 = *v8 & 0xFFFFFF0F | 0xC0;
  *v9 |= 0x80u;
  *v9 &= 0xFFFFFF8F;
  *v9 |= 0x400u;
  *v9 = *v9 & 0xFFFFFCFF | 0x100;
  *v10 &= 0xFFFE00FF;
  *v10 |= 0x20000u;
  *v10 |= 0x40000u;
  v145 = *v12;
  v144 = *v12;
  v143 = *(uint32_t *)off_108410;
  v142 = *(uint32_t *)off_108410;
  v141 = *(uint32_t *)off_108414;
  v140 = *(uint32_t *)off_108414;
  v139 = *(uint32_t *)off_108418;
  v138 = *(uint32_t *)off_108418;
  v137 = *(uint32_t *)off_10841C;
  v136 = *(uint32_t *)off_10841C;
  v135 = *v13;
  v134 = *v13;
  v133 = *v13;
  v132 = *v13;
  v131 = *v13;
  v130 = *v11;
  v129 = *v11;
  v128 = *v14;
  v127 = *v14;
  v126 = *v14;
  v125 = *v14;
  v124 = *v7;
  v123 = *v7;
  v122 = *v7;
  v121 = *v7;
  v120 = *(uint32_t *)off_108420;
  v119 = *(uint32_t *)off_108424;
  v118 = *v8;
  v117 = *(uint32_t *)off_108428;
  v116 = *v8;
  v115 = *(uint32_t *)off_10842C;
  v114 = *(uint32_t *)off_108430;
  v112 = *v7;
  v113 = *v7;
  *v11 |= 0x8000u;
  *v11 &= 0xFFFF8FFF;
  *v11 &= ~0x800u;
  *v14 |= 0x800000u;
  v15 = a4;
  *v14 |= 0x400000u;
  LOBYTE(a4) = 90;
  do
    a4 = (uint8_t)(a4 - 1);
  while ( a4 );
  v17 = off_10840C;
  *(uint32_t *)off_10840C &= ~0x100000u;
  *(uint32_t *)v17 |= 0x200000u;
  LOBYTE(v17) = 60;
  do
    v17 = (void *)(uint8_t)((uint8_t)v17 - 1);
  while ( v17 );
  v18 = off_108400;
  *(uint32_t *)off_10840C |= 0x100000u;
  *(uint32_t *)v18 |= 0x20000u;
  *(uint32_t *)v18 |= 0x10000u;
  LOBYTE(v18) = 90;
  do
    v18 = (void *)(uint8_t)((uint8_t)v18 - 1);
  while ( v18 );
  v19 = off_108400;
  *(uint32_t *)off_108400 &= ~0x40000u;
  *(uint32_t *)v19 |= 0x80000u;
  LOBYTE(v19) = 60;
  do
    v19 = (void *)(uint8_t)((uint8_t)v19 - 1);
  while ( v19 );
  v20 = off_108400;
  *(uint32_t *)off_108400 |= 0x40000u;
  *v20 |= 0x8000u;
  *v20 |= 0x4000u;
  LOBYTE(v21) = 90;
  do
    v21 = (uint8_t)(v21 - 1);
  while ( v21 );
  v22 = off_108420;
  v23 = off_108424;
  v24 = (unsigned int *)off_108434;
  *(uint32_t *)off_108420 |= 0x40000u;
  *v23 |= 0x3000u;
  v25 = off_108400;
  *v24 = *v24 & 0xFFFFFFFC | 1;
  v22[16] = v22[16] & 0xFFE3FFFF | 0xC0000;
  *v24 |= 4u;
  *v25 |= 0x800000u;
  *v25 |= 0x400000u;
  sub_103B54();
  sub_12EB90(1, dword_10876C);
  v111 = *(uint32_t *)off_108770;
  *(uint32_t *)off_108770 = *(uint32_t *)off_108770 & 0xFFFFFFF | 0x10000000;
  do
  {
    sub_103FF4(v21, 0);
    v26 = (uint8_t)(v21 + 1);
    v21 = (uint8_t)(v21 + 2);
    sub_103FF4(v26, 0);
  }
  while ( v21 != 32 );
  v27 = off_108774;
  *(uint32_t *)off_108774 &= ~0x200u;
  *v27 |= 0x200u;
  *v27 &= ~0x200u;
  sub_107084();
  if ( a3 == 255 )
  {
    v28 = (unsigned int *)off_1087B4;
    v29 = (int *)off_1087B8;
    v30 = (int *)off_1087BC;
    v31 = *(uint32_t *)(dword_108778 + 4);
    v32 = *(uint32_t *)(dword_108778 + 8);
    v164[0] = *(uint32_t *)dword_108778;
    v164[1] = v31;
    v164[2] = v32;
    memset(v165, 0, sizeof(v165));
    v33 = 0;
    v107 = 6;
    do
    {
      if ( v33 )
      {
        if ( v33 == 1 )
        {
          v167 = 24;
          v34 = 1;
          v163 = a2 + 1;
        }
        else
        {
          v167 = 15;
          v163 = a2;
          v34 = 0;
        }
      }
      else
      {
        v167 = 15;
        v163 = a2 + 2;
        v34 = 2;
      }
      sub_12EB90(1, dword_10877C);
      sub_1058D0(a2[v33], v171);
      sub_12EB90(1, dword_108780);
      if ( v173 <= 0 )
      {
        v104 = v164[v34];
      }
      else
      {
        v161 = v34;
        v105 = 2 * (4 * v34 + 1);
        v160 = v34 << 12;
        v35 = dword_108784;
        v36 = dword_1087C0;
        v104 = v164[v34];
        v103 = a1 + 32 * v34;
        v106 = &v172;
        v109 = 0;
        v110 = v107 << 8;
        do
        {
          v37 = dword_10878C;
          *(uint32_t *)off_108790 = dword_108788 | v160 | (*(uint32_t *)v106 << 8);
          v106 += 4;
          sub_12EB90(1, v37);
          sub_12EB90(1, dword_108794);
          v168 = 0;
          sub_107620((int)&v166);
          v38 = v107;
          for ( i = v110; ; i = v38 << 8 )
          {
            *v28 = i & 0xF00 | *v28 & 0xFFFFF0FF;
            *v29 &= v35;
            *v29 &= v36;
            *v30 &= v35;
            *v30 &= v36;
            sub_10794C((int)&v166);
            sub_107CC8();
            sub_1080A8();
            sub_107B08((int)&v166);
            sub_107D30();
            sub_1080F8();
            v40 = *v30 & 0xFFF;
            v41 = (*v30 & 0x8000000) != 0 ? (HIWORD(*v30) & 0xFFF) - 4096 : HIWORD(*v30) & 0xFFF;
            v42 = (*v30 & 0x800) != 0 ? v40 - 4096 : *v30 & 0xFFF;
            if ( v41 <= 1024 && v42 <= 1024 )
              break;
            v38 = (uint8_t)(v38 - 1);
            sub_12EB90(1, dword_109178);
          }
          v107 = v38;
          v110 = i;
          v43 = HIWORD(*v30) & 0xFFF;
          *v28 = ((v38 + 1) << 8) & 0xF00 | *v28 & 0xFFFFF0FF;
          sub_12EB90(1, dword_108798);
          *v30 = dword_10879C & (v43 << 17) | *v30 & v35;
          sub_10794C((int)&v166);
          sub_107CC8();
          sub_1080A8();
          sub_12EB90(1, dword_1087A0);
          *v30 = (2 * v40) & 0xFFF | *v30 & v36;
          sub_107B08((int)&v166);
          sub_107D30();
          sub_1080F8();
          v44 = dword_1087A4;
          v45 = HIWORD(*v30) & 0xFFF;
          v46 = *v30 & 0xFFF;
          v47 = v46 + (v45 << 16);
          *(uint32_t *)(v103 + 8) = v47;
          *(uint32_t *)(v103 + 8) = v47 | (*v28 >> 8 << 28);
          v99 = v45 << 16;
          sub_12EB90(1, v44);
          *v30 &= v35;
          *v30 &= v36;
          sub_107538((int)&v166, 1);
          v165[0] = v170;
          sub_10788C(v165, (int)&v166);
          sub_107444((int)&v166, 1);
          v48 = v170;
          sub_12EB90(1, dword_1087A8);
          *v30 = *v30 & v35 | v99;
          *v30 = v46 | *v30 & v36;
          sub_107444((int)&v166, 1);
          v49 = v170;
          sub_12EB90(1, dword_1087AC);
          if ( v48 <= v49 )
          {
            sub_12EB90(1, dword_109180);
            v104 = 0;
            *(uint32_t *)(v103 + 8) = 0;
          }
          else
          {
            v104 &= 1u;
            sub_12EB90(1, dword_1087B0);
          }
          v164[v161] = v104;
          sub_12EB90(1, dword_108AAC);
          sub_12EB90(1, dword_108AB0);
          v50 = dword_108AB4;
          v51 = dword_108AB8;
          *v30 = *v30 & v35 | ((*(uint16_t *)(v103 + 10) & 0xFFF) << 16);
          *v30 = *(uint32_t *)(v103 + 8) & 0xFFF | *v30 & v36;
          sub_12EB90(1, v50);
          sub_12EB90(1, dword_108ABC);
          v52 = (int *)off_108AC0;
          v53 = (unsigned int *)off_108AC4;
          v54 = (unsigned int *)off_108AC8;
          *v28 &= ~0x40000000u;
          *v28 &= 0xCFFFFFFF;
          v55 = *v52 & v36;
          v171[6] = 1;
          v174 = 600;
          v175 = 600;
          v176 = 0;
          v177 = 0;
          v166 = 0;
          *v52 = v55 | 0x300;
          *v53 = *v53 & 0xFFFFFF8F | 0x50;
          *v54 = *v54 & 0xFFF0FFFF | 0x10000;
          *v54 = *v54 & 0xFFFF0FFF | 0x1000;
          *v54 = *v54 & 0xFFFFF0FF | 0x100;
          *v54 = *v54 & 0xFFFFFF0F | 0x20;
          *v54 = *v54 & 0xFFFFFFF0 | 3;
          v168 = 10;
          v56 = 0;
          sub_107620((int)&v166);
          v108 = 0;
          do
          {
            while ( 1 )
            {
              v101 = v174;
              v102 = v175;
              v57 = v176;
              v100 = v177;
              v166 = v56;
              sub_107DA4(&v174);
              sub_107E14((int)&v174, &v166);
              sub_107F40((int)&v166, &v174, v171);
              if ( v56 )
                break;
              if ( v169 )
              {
                v56 = 1;
              }
              else
              {
                sub_12EB90(1, dword_10917C);
                ++v108;
                v168 += 6;
                sub_107620((int)&v166);
                v174 = v101;
                v175 = v102;
                v176 = v57;
                v177 = v100;
                v56 = v108 > 2;
              }
              sub_12EB90(1, v51);
            }
            ++v56;
            sub_12EB90(1, v51);
          }
          while ( v56 != 5 );
          v73 = dword_108E3C;
          v74 = dword_108E38 & (v177 << 16);
          v75 = v176 & 0xFFF;
          *(uint32_t *)(v103 + 12) = v74 + (((*v28 >> 12) & 7) << 28) + ((HIWORD(*v28) & 7) << 12) + v75;
          sub_12EB90(1, v73);
          sub_12EB90(1, dword_108E40);
          *v29 &= v35;
          *v29 &= v36;
          sub_107538((int)&v166, 0);
          v165[0] = v170;
          sub_10788C(v165, (int)&v166);
          sub_107444((int)&v166, 0);
          v76 = v170;
          sub_12EB90(1, dword_108E44);
          *v29 = v74 | *v29 & v35;
          *v29 = v75 | *v29 & v36;
          sub_107444((int)&v166, 0);
          v77 = v170;
          sub_12EB90(1, dword_108E48);
          v78 = (unsigned int *)off_108E50;
          v79 = (unsigned int *)off_108E54;
          *(uint32_t *)off_108E4C = *(uint32_t *)off_108E4C & v36 | 0xC0;
          *v78 = *v78 & 0xFFFFFF8F | 0x40;
          *v79 = *v79 & 0xFFF0FFFF | 0x10000;
          *v79 = *v79 & 0xFFFF0FFF | 0x1000;
          *v79 = *v79 & 0xFFFFF0FF | 0x100;
          *v79 = *v79 & 0xFFFFFF0F | 0x10;
          *v79 = *v79 & 0xFFFFFFF0 | 1;
          if ( v76 <= v77 )
          {
            sub_12EB90(1, dword_109184);
            *(uint32_t *)(v103 + 12) = 0;
          }
          else
          {
            sub_12EB90(1, dword_108E58);
          }
          v103 += 8;
          v80 = v173 <= ++v109;
          v105 += 2;
        }
        while ( !v80 );
      }
      v81 = dword_108E5C;
      *v163 = *v163 & 0xFFFDFFFF | (v104 << 17);
      sub_12EB90(1, v81);
      sub_12EB90(1, dword_108E60);
      ++v33;
    }
    while ( v33 != 3 );
    sub_10728C();
    v82 = (unsigned int *)off_108E64;
    v83 = (unsigned int *)off_108E68;
    v84 = (unsigned int *)off_108E90;
    v85 = (unsigned int *)off_108E94;
    v86 = off_108E98;
    v87 = off_108E9C;
    *(uint32_t *)off_108E64 = v130 & 0x8000 | *(uint32_t *)off_108E64 & 0xFFFF7FFF;
    v88 = (unsigned int *)off_108E6C;
    *v82 = v129 & 0x7000 | *v82 & 0xFFFF8FFF;
    v89 = (unsigned int *)off_108E70;
    *v83 = v158 & 0x7000000 | *v83 & 0xF8FFFFFF;
    *v82 = *v82 & 0xFFFFF7FF | v148 & 0x800;
    v90 = (unsigned int *)off_108E74;
    *v88 = *v88 & 0xFFFBFFFF | v146 & 0x40000;
    v91 = (unsigned int *)off_108E78;
    *v88 = *v88 & 0xFFF7FFFF | v147 & 0x80000;
    v92 = (unsigned int *)off_108E7C;
    *v89 = *v89 & 0xFF7FFFFF | v128 & 0x800000;
    *v89 = *v89 & 0xFFBFFFFF | v127 & 0x400000;
    v93 = dword_108E80;
    *v89 = *v89 & 0xFFEFFFFF | v126 & 0x100000;
    *v89 = v125 & 0x200000 | *v89 & 0xFFDFFFFF;
    v94 = off_108E84;
    *v88 = v124 & 0x20000 | *v88 & 0xFFFDFFFF;
    *v88 = v123 & 0x10000 | *v88 & 0xFFFEFFFF;
    *v88 = v122 & 0x8000 | *v88 & 0xFFFF7FFF;
    v95 = (unsigned int *)off_108E54;
    *v88 = v121 & 0x4000 | *v88 & 0xFFFFBFFF;
    v96 = off_108E88;
    *v84 = v120 & 0x40000 | *v84 & 0xFFFBFFFF;
    *(uint32_t *)off_108E88 = v119 & 0x3000 | *v96 & 0xFFFFCFFF;
    v97 = off_108E8C;
    *v90 = v118 & 3 | *v90 & 0xFFFFFFFC;
    *(uint32_t *)off_108E8C = v117 & 0x1C0000 | *v97 & 0xFFE3FFFF;
    *v90 = v116 & 4 | *v90 & 0xFFFFFFFB;
    *v88 = v113 & 0x800000 | *v88 & 0xFF7FFFFF;
    *v88 = v112 & 0x400000 | *v88 & 0xFFBFFFFF;
    *v88 = v157 & 0x200000 | *v88 & 0xFFDFFFFF;
    *v88 = v156 & 0x100000 | *v88 & 0xFFEFFFFF;
    *v90 = v155 & 0xF0 | *v90 & 0xFFFFFF0F;
    *v91 = v154 & 0x80 | *v91 & 0xFFFFFF7F;
    *v91 = v153 & 0x70 | *v91 & 0xFFFFFF8F;
    *v91 = v152 & 0x400 | *v91 & 0xFFFFFBFF;
    *v91 = v151 & 0x300 | *v91 & 0xFFFFFCFF;
    *v92 = *v92 & 0xFFBFFFFF | v150 & 0x400000;
    *v92 = *v92 & 0xFFDFFFFF | v149 & 0x200000;
    result = off_10916C;
    *v92 &= 0xFFFE00FF;
    *v92 &= ~0x20000u;
    *v92 |= 0x40000u;
    *v85 = *v85 & v93 | v145 & 0x3FFF;
    *v85 = *v85 & 0xC000FFFF | ((HIWORD(v144) & 0x3FFF) << 16);
    *v94 = *v94 & v93 | v143 & 0x3FFF;
    *v94 = *v94 & 0xC000FFFF | ((HIWORD(v142) & 0x3FFF) << 16);
    *result = *result & v93 | v141 & 0x3FFF;
    *result = *result & 0xC000FFFF | ((HIWORD(v140) & 0x3FFF) << 16);
    *v86 = *v86 & v93 | v139 & 0x3FFF;
    *v86 = *v86 & 0xC000FFFF | ((HIWORD(v138) & 0x3FFF) << 16);
    *v87 = v93 & *v87 | v137 & 0x3FFF;
    *v87 = *v87 & 0xC000FFFF | ((HIWORD(v136) & 0x3FFF) << 16);
    *v95 = v135 & 0xF0000 | *v95 & 0xFFF0FFFF;
    *v95 = v134 & 0xF000 | *v95 & 0xFFFF0FFF;
    *v95 = v133 & 0xF00 | *v95 & 0xFFFFF0FF;
    *v95 = v132 & 0xF0 | *v95 & 0xFFFFFF0F;
    v98 = (unsigned int *)off_109170;
    *v95 = *v95 & 0xFFFFFFF0 | v131 & 0xF;
    *v98 = *v98 & 0x7FFFFFFF | v115 & 0x80000000;
    *(uint32_t *)off_109174 = v114;
    *(v84 - 19976) = *(unsigned int *)((char *)v84 + 0xFFFFFFE0 - 79872) & 0xFFFFFFF | v111 & 0xF0000000;
  }
  else
  {
    v58 = dword_108AD0;
    v59 = ((int)((unsigned uint64_t)(dword_108ACC * (uint64_t)a3) >> 32) >> 5) - (a3 >> 31);
    v60 = a3 - 100 * v59;
    sub_103A54();
    v61 = off_108AD4;
    v62 = dword_108AD8;
    *(uint32_t *)off_108AD4 &= ~1u;
    v167 = 30;
    v168 = v59;
    sub_12E948(v62, v59, v61);
    v63 = HIWORD(v15) & 0xFFF;
    v64 = v15 & 0xFFF;
    sub_12E948(dword_108ADC, v60, v65);
    sub_12E948(dword_108AE0, v63, v64);
    *(uint32_t *)off_108AE4 = a6;
    sub_12E948(dword_108AE8, a6, a6);
    v66 = off_108AC0;
    v67 = dword_108AEC;
    *(uint32_t *)off_108AC0 = *(uint32_t *)off_108AC0 & v58 | a7 & 0xFFF;
    sub_12E948(v67, a7, v66);
    sub_103B8C(v60);
    v68 = (unsigned int *)off_108AC8;
    v69 = (int *)off_108AF0;
    v70 = dword_108AF4;
    v71 = (int *)off_108AF8;
    *(uint32_t *)off_108AC8 = *(uint32_t *)off_108AC8 & 0xFFF0FFFF | 0x10000;
    *v68 = *v68 & 0xFFFF0FFF | 0x1000;
    *v68 = *v68 & 0xFFFFF0FF | 0x100;
    *v68 = *v68 & 0xFFFFFF0F | 0x20;
    *v68 = *v68 & 0xFFFFFFF0 | 3;
    *v69 = *v69 & v70 | (v63 << 16);
    *v69 = v64 | *v69 & v58;
    *v71 = *v71 & v70 | ((HIWORD(a5) & 0xFFF) << 16);
    *v71 = a5 & 0xFFF | *v71 & v58;
    sub_1073D8();
    sub_107620((int)&v166);
    sub_107444((int)&v166, 0);
    sub_12EB90(1, dword_108AFC);
    sub_107444((int)&v166, 0);
    sub_12EB90(1, dword_108AFC);
    sub_100644(500);
    return (uint32_t *)sub_103E14();
  }
  return result;
}

