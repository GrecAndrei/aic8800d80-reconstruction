#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <inttypes.h>

#define LOBYTE(x) ((uint8_t)((x) & 0xFF))
#define HIBYTE(x) ((uint8_t)(((x) >> 8) & 0xFF))
#define LOWORD(x) ((uint16_t)((x) & 0xFFFF))
#define HIWORD(x) ((uint16_t)(((x) >> 16) & 0xFFFF))
#define LODWORD(x) ((uint32_t)(x))
#define HIDWORD(x) ((uint32_t)(((uint64_t)(x) >> 32)))

extern uint32_t off_10C82C;
extern uint32_t dword_10C830;
extern uint32_t dword_10C834;
extern uint32_t off_10C838;
extern uint32_t off_10C83C;
extern uint32_t off_10C840;

// sub_10C7B8 @ 0x10c7b8, size 114 bytes
int *sub_10C7B8()
{
  int v0; // r4
  int v1; // zf
  uint8_t v2; // r1
  int **v3; // r4

  v0 = *((uint32_t *)off_10C82C + 23);
  sub_100200((int *)dword_10C830, 0, 0x28u);
  sub_100200((int *)dword_10C834, 0, 0x1E6Cu);
  if ( (*(uint32_t *)off_10C838 & 8) != 0 )
  {
    while ( (*(uint32_t *)off_10C838 & 0x10) == 0 )
      ;
    v3 = (int **)off_10C83C;
  }
  else
  {
    v2 = v0 & 3;
    v1 = (v0 & 3) == 0;
    v3 = (int **)off_10C83C;
    *(uint32_t *)off_10C838 |= 8u;
    if ( v1 )
      sub_100200(*v3, v2, 0x288u);
    *(uint32_t *)off_10C838 |= 0x10u;
  }
  (*v3)[161] = *(uint32_t *)off_10C840;
  return sub_10C700();
}

