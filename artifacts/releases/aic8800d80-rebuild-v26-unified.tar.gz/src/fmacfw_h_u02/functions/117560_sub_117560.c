#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <inttypes.h>

#define LOBYTE(x) ((uint8_t)((x) & 0xFF))
#define HIBYTE(x) ((uint8_t)(((x) >> 8) & 0xFF))
#define LOWORD(x) ((uint16_t)((x) & 0xFFFF))
#define HIWORD(x) ((uint16_t)(((x) >> 16) & 0xFFFF))
#define LODWORD(x) ((uint32_t)(x))
#define HIDWORD(x) ((uint32_t)(((uint64_t)(x) >> 32)))

extern uint32_t dword_11774C;
extern uint32_t off_117748;
extern uint32_t dword_117780;
extern uint32_t off_117750;
extern uint32_t dword_117754;
extern uint32_t off_117758;
extern uint32_t off_11775C;
extern uint32_t dword_11777C;
extern uint32_t off_117760;
extern uint32_t off_117764;
extern uint32_t off_117768;
extern uint32_t off_11776C;
extern uint32_t off_117770;
extern uint32_t off_117774;
extern uint32_t dword_117778;

// sub_117560 @ 0x117560, size 488 bytes
int  sub_117560(int a1, int a2)
{
  char *v4; // r7
  int v5; // r10
  int v6; // r8
  int v7; // r11
  int v8; // r9
  int v10; // r3
  int16_t v11; // r1
  int v12; // r6
  int v13; // r3
  int *v14; // r6
  int v15; // r2
  char v16; // r3
  int v17; // r0
  int v18; // r1
  uint8_t *v19; // r3
  int v20; // r3
  int v21; // r2
  int v22; // r2
  int v23; // r1
  int16_t v24; // r3
  int *v25; // r3
  int v26; // r3
  int v27; // r2
  int v28; // r3
  int v29; // r2
  uint32_t *v30; // r3
  int v31; // [sp+4h] [bp-8h]

  if ( a2 == 5 )
    v4 = (char *)dword_11774C;
  else
    v4 = (char *)off_117748 + 84 * a2;
  v5 = *(uint8_t *)(a1 + 28);
  v6 = dword_117780;
  v7 = *(uint32_t *)(a1 + 76);
  v8 = dword_117780 + 1320 * v5;
  if ( sub_116DBC(v8)
    && ((v10 = *(uint8_t *)(a1 + 28), *(uint8_t *)(v6 + 1320 * v10 + 106))
     || *(uint8_t *)(a1 + 29) > 0x23u
     || *(uint16_t *)(a1 + 4)
     || (v11 = *(uint16_t *)(*(uint32_t *)(a1 + 72) + 108), (uint8_t)v11 != 192)
     && (uint8_t)v11 != 176
     && (v11 & 0xDF) != 0
     || (v12 = *((uint32_t *)off_117750 + 10)) == 0
     || *(uint8_t *)(v12 + 24) <= 2u
     || (v13 = *(uint32_t *)(v6 + 1320 * v10 + 72)) == 0
     || (v31 = v13, sub_12E948(dword_117754, v12 == v13, (uint8_t)v11), v12 == v31))
    && sub_1369C8(a1) )
  {
    *(uint32_t *)(v7 + 68) |= 0x100u;
    if ( (__get_CPSR() & 1) == 0 )
    {
      __disable_irq();
      *(uint32_t *)off_117758 = 1;
    }
    v14 = (int *)off_11775C;
    v15 = *((uint32_t *)v4 + 11);
    v16 = v4[80] + 1;
    ++*(uint32_t *)off_11775C;
    v4[80] = v16;
    if ( v15 )
      sub_119D88(a2);
    if ( !*((uint32_t *)v4 + 5) )
    {
      v30 = *(uint32_t **)(a1 + 72);
      v30[4] = dword_11777C;
      v30[2] = a1;
      v30[3] = a1;
    }
    v17 = sub_12D108(v4 + 12);
    v18 = *((uint32_t *)off_117760 + 8);
    ++*((uint32_t *)off_117748 + 126);
    if ( v18 )
    {
      v19 = *(uint8_t **)off_117764;
      v17 = 0x80000000;
      *(uint32_t *)off_117768 = 0x80000000;
      if ( *v19 == 3 && v18 == v8 )
        *(uint32_t *)(v6 + 1320 * v5 + 120) = *((uint32_t *)off_11776C + 4);
    }
    if ( **(uint8_t **)off_117770 == 2 && (*(uint32_t *)off_117774 & dword_117778) == 0 )
      sub_114434(v17, v18, *(uint32_t *)off_117774);
    if ( *v14 )
    {
      v20 = *v14 - 1;
      v21 = *(uint32_t *)off_117758;
      *v14 = v20;
      if ( !v20 )
      {
        if ( v21 )
          __enable_irq();
      }
    }
    if ( (__get_CPSR() & 1) == 0 )
    {
      __disable_irq();
      *(uint32_t *)off_117758 = 1;
    }
    v22 = *v14;
    v23 = *v14 + 1;
    v24 = *(uint16_t *)(a1 + 82) | 1;
    *v14 = v23;
    *(uint16_t *)(a1 + 82) = v24;
    if ( v23 )
    {
      v25 = (int *)off_117758;
      *v14 = v22;
      v26 = *v25;
      if ( !v22 )
      {
        if ( v26 )
          __enable_irq();
      }
    }
    if ( (__get_CPSR() & 1) == 0 )
    {
      __disable_irq();
      *(uint32_t *)off_117758 = 1;
    }
    v27 = *(uint32_t *)(a1 + 72);
    ++*v14;
    sub_116974(a1, a1, v27, a2);
    if ( *v14 )
    {
      v28 = *v14 - 1;
      v29 = *(uint32_t *)off_117758;
      *v14 = v28;
      if ( !v28 )
      {
        if ( v29 )
          __enable_irq();
      }
    }
    return 1;
  }
  else if ( *(uint8_t *)(a1 + 29) == 255 )
  {
    sub_118BBC(a1, 0);
    return 0;
  }
  else
  {
    sub_116540((uint8_t *)a1, a2);
    return 1;
  }
}

