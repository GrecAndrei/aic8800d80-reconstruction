// sub_1343EC @ 0x1343ec, size 52 bytes
_DWORD *sub_1343EC()
{
  if ( **(__int16 **)off_134420 >= 0 || !*((_DWORD *)off_134428 + 6) )
    return sub_12D240((_DWORD *)dword_134424);
  sub_12F46C(dword_13442C, dword_134430, 132);
  return sub_12D240((_DWORD *)dword_134424);
}

