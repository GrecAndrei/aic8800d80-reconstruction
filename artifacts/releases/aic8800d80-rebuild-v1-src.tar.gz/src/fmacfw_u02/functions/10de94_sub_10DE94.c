#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <inttypes.h>

#define LOBYTE(x) ((uint8_t)((x) & 0xFF))
#define HIBYTE(x) ((uint8_t)(((x) >> 8) & 0xFF))
#define LOWORD(x) ((uint16_t)((x) & 0xFFFF))
#define HIWORD(x) ((uint16_t)(((x) >> 16) & 0xFFFF))
#define LODWORD(x) ((uint32_t)(x))
#define HIDWORD(x) ((uint32_t)(((uint64_t)(x) >> 32)))

extern uint32_t off_10DEF4;
extern uint32_t dword_10DEF8;
extern uint32_t off_10DEFC;
extern uint32_t off_10DF04;
extern uint32_t dword_10DF08;
extern uint32_t off_10DF00;

// sub_10DE94 @ 0x10de94, size 94 bytes
int sub_10DE94()
{
  uint32_t *v0; // r1
  uint32_t *v1; // r3
  int result; // r0

  sub_10DCA4(1);
  sub_10DCEC(1);
  sub_10DCA4(2);
  sub_10DCEC(2);
  if ( *((uint8_t *)off_10DEF4 + 369) )
  {
    sub_10DD00(1);
    sub_10DD00(2);
  }
  else
  {
    sub_10DD14(1);
    sub_10DD14(2);
  }
  sub_10DCD4(3);
  sub_10DD44(3, 2, dword_10DEF8);
  v0 = off_10DEFC;
  v1 = off_10DF04;
  result = dword_10DF08;
  *((uint32_t *)off_10DEFC + 1) = off_10DF00;
  v1[1] = result;
  v1[2] = 0;
  v0[2] = 0;
  return result;
}

