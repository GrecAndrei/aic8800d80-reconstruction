#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <inttypes.h>

#define LOBYTE(x) ((uint8_t)((x) & 0xFF))
#define HIBYTE(x) ((uint8_t)(((x) >> 8) & 0xFF))
#define LOWORD(x) ((uint16_t)((x) & 0xFFFF))
#define HIWORD(x) ((uint16_t)(((x) >> 16) & 0xFFFF))
#define LODWORD(x) ((uint32_t)(x))
#define HIDWORD(x) ((uint32_t)(((uint64_t)(x) >> 32)))

extern uint32_t dword_102F48;
extern uint32_t dword_102F40;
extern uint32_t off_102F44;

// sub_102EB8 @ 0x102eb8, size 136 bytes
int  sub_102EB8(int a1, int a2, unsigned int a3, int a4)
{
  int v6; // r6
  int v7; // r4
  int v8; // r10
  int v9; // r12
  int v10; // r2
  int v11; // r6
  int v12; // lr
  int *v13; // r7
  int *v14; // r1
  uint32_t *v15; // r4
  int v16; // t1
  int result; // r0

  if ( a1 )
  {
    v6 = 16 * (dword_102F48 + a2);
    v7 = 4;
    v8 = 3;
  }
  else
  {
    v6 = 32 * (dword_102F40 + a2);
    v7 = 8;
    v8 = 5;
  }
  while ( !*(uint32_t *)off_102F44 )
    ;
  crypto_hw_enable_2ca8(a1);
  if ( a3 )
  {
    v9 = 0;
    v10 = 4 * (v7 - v8);
    v11 = v6 - a4;
    v12 = 0;
    v13 = (int *)(a4 + 4 * v8);
    do
    {
      v14 = (int *)(a4 + 4 * v9);
      do
      {
        v15 = (int *)((char *)v14 + v11);
        v16 = *v14++;
        *v15 = v16;
      }
      while ( v13 != v14 );
      ++v12;
      v9 += v8;
      v11 += v10;
      v13 += v8;
    }
    while ( a3 > (uint8_t)v12 );
  }
  result = sub_102D0C(a1);
  *(uint32_t *)off_102F44 = 1;
  return result;
}

