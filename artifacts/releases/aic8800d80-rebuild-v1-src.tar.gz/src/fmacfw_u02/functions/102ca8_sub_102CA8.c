#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <inttypes.h>

#define LOBYTE(x) ((uint8_t)((x) & 0xFF))
#define HIBYTE(x) ((uint8_t)(((x) >> 8) & 0xFF))
#define LOWORD(x) ((uint16_t)((x) & 0xFFFF))
#define HIWORD(x) ((uint16_t)(((x) >> 16) & 0xFFFF))
#define LODWORD(x) ((uint32_t)(x))
#define HIDWORD(x) ((uint32_t)(((uint64_t)(x) >> 32)))

extern uint32_t off_102D08;

// sub_102CA8 @ 0x102ca8, size 96 bytes
int * sub_102CA8(int a1)
{
  int v1; // r4
  int v2; // r1
  int v3; // zf
  int v4; // r2
  int v5; // r2
  int v6; // r3
  int *result; // r0
  int v8; // r2
  int v9; // r3

  v2 = (int)off_102D08;
  v3 = a1 == 0;
  if ( a1 )
    v4 = -2;
  else
    v4 = -17;
  v5 = v4 & *(uint32_t *)off_102D08;
  if ( !a1 )
    a1 = -33;
  *(uint32_t *)off_102D08 = v5;
  if ( v3 )
    v2 = 64;
  else
    a1 = -3;
  if ( v3 )
    v1 = 16;
  else
    v2 = 4;
  if ( !v3 )
    v1 = 1;
  LOBYTE(v6) = 50;
  do
    v6 = (uint8_t)(v6 - 1);
  while ( v6 );
  v9 = v5 & a1;
  result = (int *)off_102D08;
  v8 = v9 | v2;
  *(uint32_t *)off_102D08 = v9;
  LOBYTE(v9) = 50;
  *result = v8;
  do
    v9 = (uint8_t)(v9 - 1);
  while ( v9 );
  *(uint32_t *)off_102D08 = v8 | v1;
  return result;
}

